package com.example.csc.myapplication1;

import android.content.Intent;
import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.text.FirebaseVisionText;
import com.google.firebase.ml.vision.text.FirebaseVisionTextDetector;

import java.util.List;

public class text_recognition extends AppCompatActivity {

    EditText view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_recognition);

        view=findViewById(R.id.edittext_view);

        Intent intent=getIntent();
        Bitmap bitmap = (Bitmap) intent.getParcelableExtra("bitmapimage");

        FirebaseVisionImage image=FirebaseVisionImage.fromBitmap(bitmap);
        FirebaseVisionTextDetector detector= FirebaseVision.getInstance().getVisionTextDetector();
        detector.detectInImage(image).addOnSuccessListener(new OnSuccessListener<FirebaseVisionText>() {
            @Override
            public void onSuccess(FirebaseVisionText firebaseVisionText) {
                processText(firebaseVisionText);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

            }
        });

    }

    private void processText(FirebaseVisionText text)
    {
        List<FirebaseVisionText.Block> blocks=text.getBlocks();

        if(blocks.size()==0)
        {
            Toast.makeText(text_recognition.this,"No Text",Toast.LENGTH_SHORT).show();
        }
        for(FirebaseVisionText.Block block:text.getBlocks()){
            String txt=block.getText();
            view.setTextSize(24);
            view.setText(txt);

        }
    }
}
