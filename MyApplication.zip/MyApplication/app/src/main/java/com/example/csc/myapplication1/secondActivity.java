package com.example.csc.myapplication1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class secondActivity extends AppCompatActivity {

    TextView textview_username,textview_email;
    FirebaseAuth mAuth;
    FirebaseUser muser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        textview_username=findViewById(R.id.textview_username);
        textview_email=findViewById(R.id.textview_email);

        mAuth=FirebaseAuth.getInstance();
        muser=mAuth.getCurrentUser();
        textview_username.setText(muser.getDisplayName());
        textview_email.setText(muser.getEmail());

    }

    @Override
    protected void onStart() {
        super.onStart();

        if(mAuth.getCurrentUser() == null)
        {
            finish();
            startActivity(new Intent(this,MainActivity.class));
        }
    }
}
